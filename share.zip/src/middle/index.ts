// export * as admin from './admin';

// import common = require('./common');

// import users = require('./users');
// import rest = require('./rest');
// import share = require('./share');

export { CommonMiddle } from './CommonMiddle';
export { ShareRoute } from './ShareRoute';
export { WechatRoute } from './WechatRoute';
export { ApiRoute } from './ApiRoute';
export { ShareAdminRoute } from './ShareAdminRoute';

